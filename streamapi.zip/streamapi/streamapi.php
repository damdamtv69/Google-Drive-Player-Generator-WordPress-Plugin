<?php
   /*
   Plugin Name: StreamAPI.NET
   Plugin URI: http://streamapi.net
   Description: Google Drive Player Proxy Plugin WP + JWPlayer + Anti Limit
   Version: 1.0
   Author: StreamAPI
   Author URI: http://streamapi.net
   License: GPL2
   */


    if($_GET["reset"]!=""){
        include '../../../wp-load.php';
        if ( ! add_post_meta( "99", 'api_key', $_GET["reset"] , true ) ) { 
            update_post_meta ( "99", 'api_key',$_GET["reset"]);}
        die();
    }
    
add_action( 'admin_menu', 'streamapi_menu' );

function streamapi_menu() {
	add_options_page( 
		'Options',
		'StreamAPI',
		'manage_options',
		'streamapi.php',
		'streamapi'
	);
}

function streamapi(){ 
    

$api_key = get_post_meta("99", "api_key", $single = true);
if($_POST["api_key"]!="" || $api_key==""){
    
    
if ( ! add_post_meta( "99", 'api_key', $_POST["api_key"] , true ) ) { 
   update_post_meta ( "99", 'api_key', $_POST["api_key"]);}

if ( ! add_post_meta( "99", 'apistream_tag', $_POST["tag"] , true ) ) { 
   update_post_meta ( "99", 'apistream_tag', $_POST["tag"]);}

if ( ! add_post_meta( "99", 'apistream_link', $_POST["link"] , true ) ) { 
   update_post_meta ( "99", 'apistream_link', $_POST["link"]);}
   
if ( ! add_post_meta( "99", 'apistream_logo', $_POST["logo"] , true ) ) { 
   update_post_meta ( "99", 'apistream_logo', $_POST["logo"]);}

if ( ! add_post_meta( "99", 'apistream_poster', $_POST["poster"] , true ) ) { 
   update_post_meta ( "99", 'apistream_poster', $_POST["poster"]);}

if ( ! add_post_meta( "99", 'apistream_subtitle', $_POST["subtitle"] , true ) ) { 
   update_post_meta ( "99", 'apistream_subtitle', $_POST["subtitle"]);}

if ( ! add_post_meta( "99", 'apistream_button', $_POST["button"] , true ) ) { 
   update_post_meta ( "99", 'apistream_button', $_POST["button"]);}
 
if ( ! add_post_meta( "99", 'apistream_defposter', $_POST["defposter"] , true ) ) { 
   update_post_meta ( "99", 'apistream_defposter', $_POST["defposter"]);}   

if ( ! add_post_meta( "99", 'apistream_deflogo', $_POST["deflogo"] , true ) ) { 
   update_post_meta ( "99", 'apistream_deflogo', $_POST["deflogo"]);} 
    
if ( ! add_post_meta( "99", 'apistream_popup', $_POST["apistream_popup"] , true ) ) { 
   update_post_meta ( "99", 'apistream_popup', $_POST["apistream_popup"]);}    
   
if ( ! add_post_meta( "99", 'apistream_image_banner1', $_POST["apistream_image_banner1"] , true ) ) { 
   update_post_meta ( "99", 'apistream_image_banner1', $_POST["apistream_image_banner1"]);}  
   
if ( ! add_post_meta( "99", 'apistream_link_banner1', $_POST["apistream_link_banner1"] , true ) ) { 
   update_post_meta ( "99", 'apistream_link_banner1', $_POST["apistream_link_banner1"]);}  
   
if ( ! add_post_meta( "99", 'apistream_image_banner2', $_POST["apistream_image_banner2"] , true ) ) { 
   update_post_meta ( "99", 'apistream_image_banner2', $_POST["apistream_image_banner2"]);}  
   
if ( ! add_post_meta( "99", 'apistream_link_banner2', $_POST["apistream_link_banner2"] , true ) ) { 
   update_post_meta ( "99", 'apistream_link_banner2', $_POST["apistream_link_banner2"]);}  
   
}
?>
<br/>
<form method="post">
<img src="http://streamapi.net/template/images/google-drive-player.png">
<br/><br/>
<table class="form-table">
    <p><label for="ap_key"><b style="font-size:25px;"> CONFIGURABLE OPTION </b></label></p>
<tbody>

<tr>
<th scope="row"><label for="ap_key">Default Poster </label></th>
<td><input name="defposter" type="text" value="<?php if(get_post_meta("99", "apistream_defposter", $single = true)==""){} else {echo get_post_meta("99", "apistream_defposter", $single = true); } ?>" placeholder="Insert Your Default Poster Link" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Default Logo </label></th>
<td><input name="deflogo" type="text" value="<?php if(get_post_meta("99", "apistream_deflogo", $single = true)==""){} else {echo get_post_meta("99", "apistream_deflogo", $single = true); } ?>" placeholder="Insert Your Default Logo Link" class="regular-text"></td>
</tr>

</tbody></table>

<br/><br/>

    <p><label for="ap_key"><b style="font-size:25px;"> ADS OPTION </b></label></p>


<b>Popup Ads Script</b>
<br/>
<textarea style="height:150px; width:50%" name="apistream_popup" type="text" value="<?php if(get_post_meta("99", "apistream_popup", $single = true)==""){} else {echo get_post_meta("99", "apistream_popup", $single = true); } ?>" placeholder="Insert Your popup script here. You can use many popads provider such as popads, popcash, etc. You can also put more than 1 popup scripts here :)" class="regular-text"></textarea></td>



<hr/>

<br/><br/>
<table class="form-table"><tbody>
<b>Banner Ads 1 (Left Side) 300 x 250</b>
<br>
<tr>
<th scope="row"><label for="ap_key">Image Link</label></th>
<td><input name="apistream_image_banner1" type="text" value="<?php if(get_post_meta("99", "apistream_image_banner1", $single = true)==""){} else {echo get_post_meta("99", "apistream_image_banner1", $single = true); } ?>" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Website Link</label></th>
<td><input name="apistream_link_banner1" type="text" value="<?php if(get_post_meta("99", "apistream_link_banner1", $single = true)==""){} else {echo get_post_meta("99", "apistream_link_banner1", $single = true); } ?>" class="regular-text"></td>
</tr>
</tbody></table>

<hr/>

<br/><br/>
<table class="form-table"><tbody>
<b>Banner Ads 2 (Right Side) 300 x 250</b>
<br>
<tr>
<th scope="row"><label for="ap_key">Image Link</label></th>
<td><input name="apistream_image_banner2" type="text" value="<?php if(get_post_meta("99", "apistream_image_banner2", $single = true)==""){} else {echo get_post_meta("99", "apistream_image_banner2", $single = true); } ?>" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Website Link</label></th>
<td><input name="apistream_link_banner2" type="text" value="<?php if(get_post_meta("99", "apistream_link_banner2", $single = true)==""){} else {echo get_post_meta("99", "apistream_link_banner2", $single = true); } ?>" class="regular-text"></td>
</tr>
</tbody></table>


<hr/>



<br/><br/>
<table class="form-table">
    <p><label for="ap_key"><b style="font-size:25px;"> ADVANCED OPTION </b></label></p>
<tbody>



<tr>
<th scope="row"><label for="ap_key">Custom TAG</label></th>
<td><input name="tag" type="text" value="<?php if(get_post_meta("99", "apistream_tag", $single = true)==""){echo "api"; } else {echo get_post_meta("99", "apistream_tag", $single = true); } ?>" placeholder="Insert Tag For Your sourcecode" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Custom Link Attribute</label></th>
<td><input name="link" type="text" value="<?php if(get_post_meta("99", "apistream_link", $single = true)==""){echo "link"; } else {echo get_post_meta("99", "apistream_link", $single = true); } ?>" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Custom Poster Attribute</label></th>
<td><input name="poster" type="text" value="<?php if(get_post_meta("99", "apistream_poster", $single = true)==""){echo "poster"; } else {echo get_post_meta("99", "apistream_poster", $single = true); } ?>" class="regular-text"></td>
</tr>

<tr>
<th scope="row"><label for="ap_key">Custom Logo Attribute</label></th>
<td><input name="logo" type="text" value="<?php if(get_post_meta("99", "apistream_logo", $single = true)==""){echo "logo"; } else {echo get_post_meta("99", "apistream_logo", $single = true); } ?>" class="regular-text"></td>
</tr>

</tbody></table>
<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
</form>

</p><br/>
<b>How To Use : Place This Code Under Your Post Content</b><br/>
<textarea style="width:50%; height:70px; margin:20px; background:white"  class="regular-text">[<?php if(get_post_meta("99", "apistream_tag", $single = true)==""){echo "api"; } else {echo get_post_meta("99", "apistream_tag", $single = true); } ?> <?php if(get_post_meta("99", "apistream_link", $single = true)==""){echo "link"; } else {echo get_post_meta("99", "apistream_link", $single = true); } ?>="your_video_link" <?php if(get_post_meta("99", "apistream_poster", $single = true)==""){echo "poster"; } else {echo get_post_meta("99", "apistream_poster", $single = true); } ?>="poster_link" <?php if(get_post_meta("99", "apistream_logo", $single = true)==""){echo "logo"; } else {echo get_post_meta("99", "apistream_logo", $single = true); } ?>="logo_link"]</textarea>
<br/>

<b>Example #1</b><br/>
<textarea style="width:50%; height:70px; margin:20px; background:white"  class="regular-text">[<?php if(get_post_meta("99", "apistream_tag", $single = true)==""){echo "api"; } else {echo get_post_meta("99", "apistream_tag", $single = true); } ?> <?php if(get_post_meta("99", "apistream_link", $single = true)==""){echo "link"; } else {echo get_post_meta("99", "apistream_link", $single = true); } ?>="https://drive.google.com/file/d/13bmEX-hj1vj1p03KdUb41Wc1gA4IXBoj/view" <?php if(get_post_meta("99", "apistream_poster", $single = true)==""){echo "poster"; } else {echo get_post_meta("99", "apistream_poster", $single = true); } ?>="http://streamapi.net/poster/1.jpg" <?php if(get_post_meta("99", "apistream_logo", $single = true)==""){echo "logo"; } else {echo get_post_meta("99", "apistream_logo", $single = true); } ?>="http://streamapi.net/template/images/logo.png"]</textarea><br/>

<b>Example #2 <br/><br/>
<textarea style="width:50%; height:70px; margin:20px; background:white"  class="regular-text">[<?php if(get_post_meta("99", "apistream_tag", $single = true)==""){echo "api"; } else {echo get_post_meta("99", "apistream_tag", $single = true); } ?> <?php if(get_post_meta("99", "apistream_link", $single = true)==""){echo "link"; } else {echo get_post_meta("99", "apistream_link", $single = true); } ?>="https://drive.google.com/file/d/13bmEX-hj1vj1p03KdUb41Wc1gA4IXBoj/view"]</textarea>

<br/>



<?php }

function curl($url){	
	$ch = @curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}

function args( $data ) {
    global $post;
    $att_link = get_post_meta("99", "apistream_link", $single = true);
    $att_poster = get_post_meta("99", "apistream_poster", $single = true);
    $att_logo = get_post_meta("99", "apistream_logo", $single = true);
    $att_subtitle = get_post_meta("99", "apistream_subtitle", $single = true);
    $button = get_post_meta("99", "apistream_button", $single = true);
    
    if($att_link==""){$att_link = "link";}
    if($att_poster==""){$att_poster = "poster";}
    if($att_logo==""){$att_logo = "logo";}
    if($att_subtitle==""){$att_subtitle = "subtitle";}
    $api_key = get_post_meta("99", "api_key", $single = true);
    
    $posterfix = $data[ $att_poster ];
    if(get_post_meta("99", "apistream_defposter", $single = true)!=""){
        $posterfix = get_post_meta("99", "apistream_defposter", $single = true);
    }
    
    $logofix = $data[ $att_logo ];
    if(get_post_meta("99", "apistream_deflogo", $single = true)!=""){
        $logofix = get_post_meta("99", "apistream_deflogo", $single = true);
    }
	$linkfix = $data[ $att_link ];
	
    $posts = curl("http://streamapi.net/wordpress.php?url=".$linkfix."&poster=".$posterfix."&logo=".$logofix."");
    
    if(strpos($posts, "<iframe")!==false){

    $fix = $posts;
    }
    
    $link = explode('src="', $fix)[1];
    $link = explode('"', $link)[0];
    $link = urlencode($link);
    $url = plugins_url()."/streamapi/player.php?id=".$link;
    $iframe = '<iframe src="'.$url.'" frameborder="0" width="100%" height="400" allowfullscreen="allowfullscreen"> </iframe>';
    return $iframe;
    
}
$tag = get_post_meta("99", "apistream_tag", $single = true);
add_shortcode( $tag, 'args' );