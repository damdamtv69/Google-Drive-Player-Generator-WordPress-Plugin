<?php 
include("../../../wp-load.php");
$loading = plugins_url()."/streamapi/loading.gif";
$url = $_GET["id"];
$url = urldecode($url);
$url = urldecode($url);
?>
<style>#player{position:absolute; top:0; left:0; width:100%; height:100%;background-color:#000;}.error_messenger{position: absolute; z-index: 99999; color: white; top: 50%; left: 30%; word-wrap: break-word; text-align: center; right: 30%;}</style>
<center>    
        <iframe id="player" src="<?php echo $url; ?>" allowfullscreen="true" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>
</center>
<?php echo get_post_meta("99", "apistream_popup", $single = true); ?>
<?php 
$banner1 = get_post_meta("99", "apistream_image_banner1", $single = true);
$banner2 = get_post_meta("99", "apistream_image_banner2", $single = true);

$link1  = get_post_meta("99", "apistream_link_banner1", $single = true);
$link2  = get_post_meta("99", "apistream_link_banner2", $single = true);

if($banner1=="" && $banner2==""){} else { ?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<style type="text/css">
.popUpBannerInner {
	max-width: 600px;
	margin: 0 auto;
}
.popUpBannerContent {
	position: fixed;
	top: 40px;
}
.closeButton {
	color: red;
	text-decoration: none;
	font-size: 18px;
}
	
	</style>
<div class="popUpBannerBox"> 
<div class="popUpBannerInner"> 
<div class="popUpBannerContent"> 
<table style="margin-left: auto; margin-right: auto;"><tr>
<td><a href="<?php echo $link1; ?>" target="_blank" rel="nofollow"><img style="width:100%"  src="<?php echo $banner1; ?>" ></a></td>
<td><a href="<?php echo $link2; ?>" target="_blank" rel="nofollow"><img style="width:100%"  src="<?php echo  $banner2; ?>"></a></td>
</tr></table>
<p><a href="#" class="closeButton" style="background:#000;display: block;text-align: center;">X Close Ads</a></p>
</div>
</div>
</div>
<script type="text/javascript">
	function showPopUpBanner() {
		$('.popUpBannerBox').fadeIn("2000");
	}
	setTimeout(showPopUpBanner, 1000);

	$('.popUpBannerBox').click(function(e) {
		if ( !$(e.target).is('.popUpBannerContent, .popUpBannerContent *' ) ) {
			$('.popUpBannerBox').fadeOut("2000");
			return false;
		}
	});

	$('.closeButton').click(function() {
		$('.popUpBannerBox').fadeOut("2000");
		return false;
	});
</script><?php } ?>